#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/time.h>
#include <stdbool.h>

#ifndef PCAPNG_H
#define PCAPNG_H

#define SHB_TYPE 0x0A0D0D0A
#define IDB_TYPE 0x00000001
#define EPB_TYPE 0x00000006

#define BOM 0x1A2B3C4D

typedef struct {
    uint32_t block_type;
    uint32_t block_length;
    uint32_t bom;      
    uint16_t major_version;
    uint16_t minor_version;
    int64_t section_length;
} shb_headers_t;

typedef struct {
    uint32_t block_type;
    uint32_t block_length;
    uint16_t link_type;
    uint16_t reserved;
    uint32_t snap_len;
} idb_headers_t;

typedef struct {
    uint32_t block_type;
    uint32_t block_length;
    uint32_t interface_id;
    uint32_t timestamp_high;
    uint32_t timestamp_low;
    uint32_t captured_len;
    uint32_t original_len;
} epb_headers_t;

typedef struct {
    FILE *pcapng_file;
    unsigned char *packet_data;
    uint32_t packet_length;
} pcapng_thread_args_t;

FILE* pcapng_init_file(const char *);
bool pcapng_write_shb_section(FILE *);
bool pcapng_write_idb_section(FILE *);
bool pcapng_write_packet(FILE *, unsigned char *, uint32_t);
bool pcapng_close_file(FILE *);

/**
 * @brief This function should be called first and only once!
 * 
 * @param pcapng_filepath The filepath of the PcapNG file.
 * @return FILE*
 */
FILE* pcapng_init_file(const char *pcapng_filepath) {
    FILE *pcapng_file = fopen(pcapng_filepath, "wb");
    if (!pcapng_write_shb_section(pcapng_file)) {
        return NULL;
    }
    if (!pcapng_write_idb_section(pcapng_file)) {
        return NULL;
    }
    return pcapng_file;
}

/**
 * @brief Write a SHB section to the PcapNG file.
 * 
 * @param pcapng_file The FILE pointer of the PcapNG file.
 * @return true on successful write.
 * @return false on write error.
 */
bool pcapng_write_shb_section(FILE *pcapng_file) {
    
    uint32_t block_length = sizeof(shb_headers_t) + sizeof(block_length);
    uint32_t padding_length = 4 - (block_length % 4);
    block_length += padding_length;

    char unsigned *padding = malloc(padding_length);
    memset(padding, 0, padding_length);

    shb_headers_t shb_headers = {
        .block_type = SHB_TYPE,
        .block_length = block_length,
        .bom = BOM,
        .major_version = 1,
        .minor_version = 0,
        .section_length = -1
    };
    if (!fwrite(&shb_headers, sizeof(shb_headers), 1, pcapng_file)) {
        return false;
    }
    if (!fwrite(padding, padding_length, 1, pcapng_file)) {
        return false;
    }
    if (!fwrite(&block_length, sizeof(block_length), 1, pcapng_file)) {
        return false;
    }
    fflush(pcapng_file);
    return true;
}

/**
 * @brief Write a IDB section to the PcapNG file.
 * 
 * @param pcapng_file The FILE pointer of the PcapNG file.
 * @return true on successful write.
 * @return false on write error.
 */
bool pcapng_write_idb_section(FILE *pcapng_file) {

    uint32_t block_length = sizeof(idb_headers_t) + sizeof(block_length);
    uint32_t padding_length = 4 - (block_length % 4);
    block_length += padding_length;

    char unsigned *padding = malloc(padding_length);
    memset(padding, 0, padding_length);

    idb_headers_t idb_headers = {
        .block_type = IDB_TYPE,
        .block_length = block_length,
        .link_type = 1,
        .reserved = 0,
        .snap_len = 65535

    };
    if (!fwrite(&idb_headers, sizeof(idb_headers), 1, pcapng_file)) {
        return false;
    }
    if (!fwrite(padding, padding_length, 1, pcapng_file)) {
        return false;
    }
    if (!fwrite(&block_length, sizeof(block_length), 1, pcapng_file)) {
        return false;
    }
    fflush(pcapng_file);
    return true;
}

/**
 * @brief Write a EPB section to the PcapNG file.
 * 
 * @param pcapng_file The FILE pointer of the PcapNG file.
 * @return true on successful write.
 * @return false on write error.
 */
bool pcapng_write_packet(FILE* pcapng_file, unsigned char *packet_data, uint32_t packet_length) {
    
    uint32_t block_length = sizeof(epb_headers_t) + packet_length + sizeof(block_length);
    uint32_t padding_length = 4 - (block_length % 4);
    block_length += padding_length;

    char unsigned *padding = malloc(padding_length);
    memset(padding, 0, padding_length);

    uint32_t ts_high = 0;
    uint32_t ts_low = 0;
    struct timeval tv;

    gettimeofday(&tv, NULL);
    uint64_t unix_epoch_microseconds = (uint64_t)tv.tv_sec * 1000000ULL + (uint64_t)tv.tv_usec;
    
    ts_high = (uint32_t)(unix_epoch_microseconds >> 32);
    ts_low = (uint32_t)(unix_epoch_microseconds);

    epb_headers_t epb_header = {
        .block_type = EPB_TYPE,
        .block_length = block_length,
        .interface_id = 0,
        .timestamp_high = ts_high,
        .timestamp_low = ts_low,
        .captured_len = packet_length,
        .original_len = packet_length
    };

    if (!fwrite(&epb_header, sizeof(epb_header), 1, pcapng_file)) {
        return false;
    }
    if (!fwrite(packet_data, packet_length, 1, pcapng_file)) {
        return false;
    }
    if (!fwrite(padding, padding_length, 1, pcapng_file)) {
        return false;
    }
    if (!fwrite(&block_length, sizeof(block_length), 1, pcapng_file)) {
        return false;
    }
    fflush(pcapng_file);
    return true;
}

/**
 * @brief Close the PcapNG file.
 * 
 * @param pcapng_file The FILE pointer of the PcapNG file.
 * @return true on successful close.
 * @return false on close error.
 */
bool pcapng_close_file(FILE *pcapng_file) {
    if(fclose(pcapng_file) == EOF) {
        return false;
    }
    return true;
}
#endif
