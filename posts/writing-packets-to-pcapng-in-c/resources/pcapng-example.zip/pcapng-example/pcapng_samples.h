#include <stdint.h>

uint8_t sample_tcp_syn[] = {
    // Ethernet header (14 bytes)
    0x00, 0x11, 0x22, 0x33, 0x44, 0x55,  // Destination MAC
    0x66, 0x77, 0x88, 0x99, 0xAA, 0xBB,  // Source MAC
    0x08, 0x00,                          // EtherType: IPv4

    // IP header (20 bytes)
    0x45,                                // Version (4) + Header Length (5)
    0x00,                                // Differentiated Services Field
    0x00, 0x28,                          // Total Length: 40 bytes
    0x1A, 0x2B,                          // Identification
    0x40, 0x00,                          // Flags (Don't Fragment) + Fragment Offset
    0x40,                                // TTL: 64
    0x06,                                // Protocol: TCP (6)
    0xB1, 0xE6,                          // Header Checksum (placeholder)
    0xC0, 0xA8, 0x01, 0x01,              // Source IP: 192.168.1.1
    0xC0, 0xA8, 0x01, 0x02,              // Destination IP: 192.168.1.2

    // TCP header (20 bytes)
    0x00, 0x50,                          // Source Port: 80
    0x1F, 0x90,                          // Destination Port: 8080
    0x00, 0x00, 0x00, 0x00,              // Sequence Number: 0
    0x00, 0x00, 0x00, 0x00,              // Acknowledgment Number: 0
    0x50,                                // Data Offset (5) + Reserved
    0x02,                                // Flags: SYN
    0x72, 0x10,                          // Window Size
    0x00, 0x00,                          // Checksum (placeholder)
    0x00, 0x00                           // Urgent Pointer
};

uint8_t sample_icmp_request[] = {
    // Ethernet header (14 bytes)
    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,  // Destination MAC: Broadcast
    0x00, 0x0A, 0x95, 0x9D, 0x68, 0x16,  // Source MAC: Arbitrary
    0x08, 0x00,                          // EtherType: IPv4

    // IPv4 header (20 bytes)
    0x45,                                // Version (4) + Header Length (5)
    0x00,                                // Differentiated Services Field
    0x00, 0x3C,                          // Total Length: 60 bytes
    0x1A, 0x2B,                          // Identification
    0x40, 0x00,                          // Flags (Don't Fragment) + Fragment Offset
    0x40,                                // TTL: 64
    0x01,                                // Protocol: ICMP (1)
    0xF7, 0xB6,                          // Header Checksum (calculated for IPv4 header)
    0xC0, 0xA8, 0x01, 0x64,              // Source IP: 192.168.1.100
    0xC0, 0xA8, 0x01, 0x65,              // Destination IP: 192.168.1.101

    // ICMP header (8 bytes)
    0x08,                                // Type: Echo Request
    0x00,                                // Code: 0
    0xF7, 0xFF,                          // Checksum (calculated for ICMP header + payload)
    0x12, 0x34,                          // Identifier: Arbitrary
    0x00, 0x01,                          // Sequence Number: 1

    // ICMP payload (32 bytes)
    0x61, 0x62, 0x63, 0x64, 0x65, 0x66, 0x67, 0x68,  // "abcdefgh"
    0x69, 0x6A, 0x6B, 0x6C, 0x6D, 0x6E, 0x6F, 0x70,  // "ijklmnop"
    0x71, 0x72, 0x73, 0x74, 0x75, 0x76, 0x77, 0x78,  // "qrstuvwx"
    0x79, 0x7A, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46   // "yzABCDEF"
};
