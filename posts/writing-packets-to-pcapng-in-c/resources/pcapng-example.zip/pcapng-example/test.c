#include "pcapng.h"
#include "pcapng_samples.h"

int main (void) {

    FILE *pcapng_file = pcapng_init_file("output.pcapng");
    pcapng_write_packet(pcapng_file, sample_tcp_syn, sizeof(sample_tcp_syn));
    pcapng_write_packet(pcapng_file, sample_icmp_request, sizeof(sample_icmp_request));
    pcapng_close_file(pcapng_file);

    return 0;
}